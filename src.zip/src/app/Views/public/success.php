<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Paiement Réussi</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>
    <div class="container">
        <h1>Paiement Validé ✅</h1>
        <p>Merci pour votre achat ! Votre commande a bien été enregistrée.</p>
        <a href="orders">Voir mes commandes</a>
    </div>
</body>
</html>
