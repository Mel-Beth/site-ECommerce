document.addEventListener("DOMContentLoaded", function () {
  const cartKey = "ecommerce_cart";

  function loadCart() {
      return JSON.parse(localStorage.getItem(cartKey)) || [];
  }

  function saveCart(cart) {
      localStorage.setItem(cartKey, JSON.stringify(cart));
  }

  function updateCartDisplay() {
      const cart = loadCart();
      const cartTable = document.querySelector("#cart-items");
      cartTable.innerHTML = "";

      if (cart.length === 0) {
          document.querySelector("#cart-empty").style.display = "block";
          document.querySelector("#cart-container").style.display = "none";
      } else {
          document.querySelector("#cart-empty").style.display = "none";
          document.querySelector("#cart-container").style.display = "block";

          cart.forEach(item => {
              const row = document.createElement("tr");
              row.innerHTML = `
                  <td>${item.name}</td>
                  <td>${(item.price * (1 - item.discount / 100)).toFixed(2)} €</td>
                  <td><input type="number" class="quantity-input" data-id="${item.id}" value="${item.quantity}" min="1"></td>
                  <td>${(item.price * item.quantity).toFixed(2)} €</td>
                  <td><button class="remove-btn" data-id="${item.id}">❌</button></td>
              `;
              cartTable.appendChild(row);
          });

          document.querySelectorAll(".quantity-input").forEach(input => {
              input.addEventListener("change", function () {
                  const cart = loadCart();
                  const productId = this.getAttribute("data-id");
                  const quantity = parseInt(this.value);

                  const itemIndex = cart.findIndex(item => item.id == productId);
                  if (itemIndex !== -1) {
                      cart[itemIndex].quantity = quantity;
                      saveCart(cart);
                      updateCartDisplay();
                  }
              });
          });

          document.querySelectorAll(".remove-btn").forEach(button => {
              button.addEventListener("click", function () {
                  const cart = loadCart();
                  const productId = this.getAttribute("data-id");

                  const newCart = cart.filter(item => item.id != productId);
                  saveCart(newCart);
                  updateCartDisplay();
              });
          });
      }
  }

  document.querySelectorAll(".add-to-cart").forEach(button => {
      button.addEventListener("click", function () {
          const productId = this.getAttribute("data-id");
          const name = this.getAttribute("data-name");
          const price = parseFloat(this.getAttribute("data-price"));
          const discount = parseFloat(this.getAttribute("data-discount")) || 0;

          const cart = loadCart();
          const existingItem = cart.find(item => item.id == productId);

          if (existingItem) {
              existingItem.quantity += 1;
          } else {
              cart.push({ id: productId, name, price, quantity: 1, discount });
          }

          saveCart(cart);
          updateCartDisplay();
      });
  });

  updateCartDisplay();
});
