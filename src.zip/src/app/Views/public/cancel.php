<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Paiement Annulé</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>
    <div class="container">
        <h1>Paiement Annulé ❌</h1>
        <p>Votre paiement a été annulé. Vous pouvez réessayer si nécessaire.</p>
        <a href="cart">Retour au panier</a>
    </div>
</body>
</html>
